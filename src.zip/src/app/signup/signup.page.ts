import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  firstname: any;
  lastname: any;
  username: any;
  password: any;
  confirmpassword: any;

  constructor(private router: Router, private toastController: ToastController) { }

  ngOnInit() {
  }
  async doSignup(){
    if (!this.firstname) {
      const toast = await this.toastController.create({
        message: 'Please enter firstname.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }

    if (!this.lastname) {
      const toast = await this.toastController.create({
        message: 'Please enter lastname.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }
    if (!this.username) {
      const toast = await this.toastController.create({
        message: 'Please enter username.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }
    if (!this.password) {
      const toast = await this.toastController.create({
        message: 'Please enter password.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }
    if (!this.confirmpassword) {
      const toast = await this.toastController.create({
        message: 'Please enter confirm password.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }
    this.router.navigate(['/dashboard']);
  }

}
