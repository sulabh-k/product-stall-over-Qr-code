import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage implements OnInit {

  Items: any = [];

  constructor(private router: Router) { }

  ngOnInit() {

  }

  ionViewDidEnter() {
    this.Items = JSON.parse(localStorage.selectedtems);
  }

  getQuantity(val) {
    if (val == '.25') {
      return '250 gm';
    } else if (val == '.5') {
      return '500 gm';
    } else if (val == '1') {
      return '1 kg';
    } else if (val == '2') {
      return '2 kg';
    } else if (val == '5') {
      return '5 kg';
    }
  }

  removeItem(i) {
    this.Items.splice(i, 1)
    localStorage.setItem('selectedtems', JSON.stringify(this.Items))
  }

  getTotal() {
    var total: any = 0;

    for (let i = 0; i < this.Items.length; i++) {
      total += this.Items[i].quantity * this.Items[i].price;
    }
    localStorage.setItem('totalAmount', total)
    return total;
  }

  checkout() {
    this.router.navigate(['checkout']);
  }


}
