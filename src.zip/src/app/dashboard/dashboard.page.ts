import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  goToCart(){
    this.router.navigate(['/cart']);
  }

  scan(){
    this.router.navigate(['/scan']);
  }
}
