import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: any;
  password: any;
  constructor(private router: Router, private toastController: ToastController) { }

  ngOnInit() {
  }

  scanPage() {
    this.router.navigate(['scan']);
  }

  async doLogin() {
    if (!this.username) {
      const toast = await this.toastController.create({
        message: 'Please enter username.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }

    if (!this.password) {
      const toast = await this.toastController.create({
        message: 'Please enter password.',
        duration: 3000,
        position: 'top',
      });
      toast.present();
      return;
    }
   // localStorage.setItem('isLogin', '1');
    this.router.navigate(['/dashboard']);
  }
  goPage(){
    this.router.navigate(['/signup']);
  }

}
