import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular';
import { PopoverComponent } from '../popover/popover.component'


@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
})
export class ListPage implements OnInit {
  newArr: any = [];
  catID: any;
  allItems: any = [];
  items: any = [];
  cartItem: any = [];
  innerHTML: string;
  constructor(private toastController: ToastController, private router: Router, public popoverController: PopoverController) { }

  ngOnInit() {
    // this.ePass = [1, 2, 3, 4, 5]
    this.catID = localStorage.scanData;
    var resp = [{
      'name': 'Himalaya Facewash',
      'shop':'sk enterprise',
      'price': '80',
      'quantity': '0',
      'img': '/assets/imgs/facewash.png',
      'catId': '12022',
      'time': '5',
      'rating' :'4'
    }, {
      'name': 'Himalaya Facewash',
      'price': '60',
      'quantity': '0',
      'img': '/assets/imgs/facewash.png',
      'catId': '12022',
      'time': '6',
      'rating' :'3'
    }, {
      'name': 'Himalaya Facewash',
      'price': '90',
      'quantity': '0',
      'img': '/assets/imgs/facewash.png',
      'catId': '12022',
      'time': '3',
      'rating' :'4'
    }, {
      'name': 'Head & Shoulder',
      'price': '120',
      'quantity': '0',
      'img': '/assets/imgs/head.png',
      'catId': '520142',
      'time': '5',
      'rating' :'3'
    }, {
      'name': 'Head & Shoulder',
      'price': '20',
      'quantity': '0',
      'img': '/assets/imgs/head.png',
      'catId': '520142',
      'time': '6',
      'rating' :'2'
    }, {
      'name': 'Monitor',
      'price': '35',
      'quantity': '0',
      'img': '/assets/imgs/monitor.png',
      'catId': '21456',
      'time': '4',
      'rating' :'3.5'
    }, {
      'name': 'Monitor',
      'price': '35',
      'quantity': '0',
      'img': '/assets/imgs/monitor.png',
      'catId': '21456',
      'time': '7',
      'rating' :'4.2'
    }, {
      'name': 'Monitor',
      'price': '45',
      'quantity': '0',
      'img': '/assets/imgs/monitor.png',
      'catId': '21456',
      'time': '6',
      'rating' :'3.8'
    }]

    this.allItems = resp;
    for (let i = 0; i < resp.length; i++) {
      if (resp[i].catId == this.catID)
        this.items.push(resp[i]);
    }
  }

  sortAsPrice() {
    this.items.sort((a, b) => a.price.localeCompare(b.price));
  }

  sortDsPrice() {
    this.newArr = this.items;
    this.items.sort((b, a) => a.price.localeCompare(b.price));
  }

  sortAsDate() {
    this.newArr = this.items;
    this.items.sort((a, b) => a.time.localeCompare(b.time));
  }

  sortRating() {
    this.newArr = this.items;
    this.items.sort((a, b) => a.rating.localeCompare(b.rating));
  }

  async addValue(val, i) {
    // if (this.dropDown[i] != '' && this.dropDown[i] != undefined) {
    val.quantity = 1
    for (var j = 0; j < this.cartItem.length; j++) {
      if (this.cartItem[j].name == val.name) {
        this.cartItem.splice(j, 1);
      }
    }
    this.cartItem.push(val);
    const toast = await this.toastController.create({
      message: 'Item added to cart',
      duration: 1000,
      position: 'bottom',
      cssClass: 'greenToast'
    });
    toast.present();
    // } else {
    //   const toast = await this.toastController.create({
    //     message: 'Please select qantity',
    //     duration: 3000,
    //     position: 'top',
    //     cssClass: 'redToast'
    //   });
    //   toast.present();
    //   return;
    // }
    console.log(this.cartItem)

  }

  goToCart() {
    localStorage.setItem('selectedtems', JSON.stringify(this.cartItem))
    this.router.navigate(['cart']);
  }

  async presentPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: PopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true
    });
    return await popover.present();
  }
  // let currentPopover = null;

  // const buttons = document.querySelectorAll('ion-button');
  // for (var i = 0; i < buttons.length; i++) {
  //   buttons[i].addEventListener('click', handleButtonClick);
  // }

  // async function handleButtonClick(ev) {
  //   const popover = await popoverController.create({
  //     component: 'popover-example-page',
  //     event: ev,
  //     translucent: true
  //   });
  //   currentPopover = popover;
  //   return popover.present();
  // }

  // function dismissPopover() {
  //   if (currentPopover) {
  //     currentPopover.dismiss().then(() => { currentPopover = null; });
  //   }
  // }

  // customElements.define('popover-example-page', class ModalContent extends HTMLElement {
  //   connectedCallback() {
  //     this.innerHTML = `
  //       <ion-list>
  //         <ion-list-header>Ionic</ion-list-header>
  //         <ion-item button>Learn Ionic</ion-item>
  //         <ion-item button>Documentation</ion-item>
  //         <ion-item button>Showcase</ion-item>
  //         <ion-item button>GitHub Repo</ion-item>
  //         <ion-item lines="none" detail="false" button onClick="dismissPopover()">Close</ion-item>
  //       </ion-list>
  //     `;
  //   }
  // });
}
