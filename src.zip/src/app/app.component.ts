import { Component, ViewChild } from '@angular/core';

import { Platform, IonRouterOutlet, NavController, AlertController} from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  public appPages = [
    {
      title: 'Home',
      url: '/dashboard',
      icon: 'home'
    },
    {
      title: 'Profile',
      url: '/profile',
      icon: 'person'
    },
    {
      title: 'About Us',
      url: '/about',
      icon: 'information-circle'
    }
  ];

  @ViewChild(IonRouterOutlet, { static: false }) routerOutlet: IonRouterOutlet;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private navCtrl: NavController,
    public alertController: AlertController,
   // private events: Events,
    private router: Router
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.backgroundColorByHexString('#4771C7');
      this.splashScreen.hide();
    });

    this.platform.backButton.subscribeWithPriority(0, () => {
      if (this.routerOutlet && this.routerOutlet.canGoBack()) {
        this.routerOutlet.pop();
      } else if (this.router.url === '/scan') {
        if (localStorage.isLogin == '1') {
          this.router.navigate(['view-pass']);
        }else{
          
        }
      } else if (this.router.url === '/generate-pass') {
        navigator['app'].exitApp();
      } else {
        navigator['app'].exitApp();
      }
    });
  }

  async logout() {
    const alert = await this.alertController.create({
      subHeader: 'Confirm Logout',
      message: 'Are you sure you want to log out?',
      cssClass: 'cstmAlert',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Logout',
          handler: () => {
            localStorage.clear();
            this.navCtrl.navigateRoot("/login");
          }
        }
      ]
    });
    await alert.present();
  }
}
