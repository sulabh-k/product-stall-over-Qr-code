import { Component, OnInit } from '@angular/core';
import { QRScanner, QRScannerStatus } from '@ionic-native/qr-scanner/ngx';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-scan',
  templateUrl: './scan.page.html',
  styleUrls: ['./scan.page.scss'],
})
export class ScanPage implements OnInit {

  constructor(private qrScanner: QRScanner, private router: Router, private navCtrl: NavController) {

  }

  ngOnInit() {
   // this.router.navigate(['list']);
    //localStorage.setItem('scanData', '12022');
  }

  ionViewDidEnter() {
    this.startScan();
  }

  startScan() {

    // Optionally request the permission early
    this.qrScanner.prepare()
      .then((status: QRScannerStatus) => {
        if (status.authorized) {
          // camera permission was granted
          //alert('authorized');

          // start scanning
          let scanSub = this.qrScanner.scan().subscribe((text: string) => {
            console.log('Scanned something', text);

            //alert(text);
            //  localStorage.setItem('scanData', '1');
            localStorage.setItem('scanData', JSON.parse(text).cat_id);
            //   localStorage.setItem('fromScan','true');
            this.qrScanner.hide(); // hide camera preview
            scanSub.unsubscribe(); // stop scanning
            //this.navCtrl.pop();
            // this.navCtrl.navigateBack('view-pass')
            this.router.navigate(['list']);
          });

          this.qrScanner.resumePreview();

          // show camera preview
          this.qrScanner.show()
            .then((data: QRScannerStatus) => {
              console.log('datashowing', data.showing);
              //alert(data.showing);
            }, err => {
              //alert(err);

            });

          // wait for user to scan something, then the observable callback will be called

        } else if (status.denied) {
          alert('denied');
          // camera permission was permanently denied
          // you must use QRScanner.openSettings() method to guide the user to the settings page
          // then they can grant the permission from there
        } else {
          // permission was denied, but not permanently. You can ask for permission again at a later time.
          alert('else');
        }
      })
      .catch((e: any) => {
        alert('Error is' + e);
      });

  }

}
